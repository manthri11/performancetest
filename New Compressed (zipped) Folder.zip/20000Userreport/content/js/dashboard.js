/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 95.62615915770252, "KoPercent": 4.373840842297486};
    var dataset = [
        {
            "label" : "KO",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "OK",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.7412203612292065, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.9925417075564279, 500, 1500, "SAML-2"], "isController": false}, {"data": [0.4453559056147461, 500, 1500, "SAML-0"], "isController": false}, {"data": [0.353, 500, 1500, "Login"], "isController": false}, {"data": [0.329675, 500, 1500, "SAML"], "isController": false}, {"data": [0.9684619909798026, 500, 1500, "SAML-1"], "isController": false}, {"data": [0.4789780282403597, 500, 1500, "Login-0"], "isController": false}, {"data": [0.9471931771715637, 500, 1500, "Logout-2"], "isController": false}, {"data": [0.9981004242385867, 500, 1500, "Login-1"], "isController": false}, {"data": [0.8679007151872108, 500, 1500, "Logout-1"], "isController": false}, {"data": [0.9469920067311738, 500, 1500, "Logout-0"], "isController": false}, {"data": [0.9204892966360856, 500, 1500, "Login-2"], "isController": false}, {"data": [0.8975535168195719, 500, 1500, "Login-3"], "isController": false}, {"data": [0.9007831394679259, 500, 1500, "Initial-3"], "isController": false}, {"data": [0.9987415551728706, 500, 1500, "Logout-6"], "isController": false}, {"data": [0.9490548091784567, 500, 1500, "Logout-5"], "isController": false}, {"data": [0.9645673515369347, 500, 1500, "Initial-1"], "isController": false}, {"data": [0.8878732659299318, 500, 1500, "Logout-4"], "isController": false}, {"data": [0.7704652532391049, 500, 1500, "Initial-2"], "isController": false}, {"data": [0.9969435137835773, 500, 1500, "Logout-3"], "isController": false}, {"data": [0.004825, 500, 1500, "Logout"], "isController": false}, {"data": [0.8951516757186382, 500, 1500, "Logout-7"], "isController": false}, {"data": [0.35985, 500, 1500, "Initial"], "isController": false}, {"data": [0.9174668740947374, 500, 1500, "Initial-0"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 350470, 15329, 4.373840842297486, 1532.348797329301, 0, 121169, 21016.0, 21031.0, 21047.0, 8.69151904947264, 54.71521041493504, 25.06988681005751], "isController": false}, "titles": ["Label", "#Samples", "KO", "Error %", "Average", "Min", "Max", "90th pct", "95th pct", "99th pct", "Throughput", "Received", "Sent"], "items": [{"data": ["SAML-2", 15285, 3, 0.019627085377821395, 272.0457311089294, 198, 21020, 334.0, 354.0, 551.2799999999988, 0.38037254759870326, 3.217051058612759, 0.32251647028217845], "isController": false}, {"data": ["SAML-0", 15299, 0, 0.0, 1054.9741159552982, 664, 3730, 1525.0, 1743.0, 2194.0, 0.3807155705800108, 0.5526594786922834, 6.8184113659315795], "isController": false}, {"data": ["Login", 20000, 2603, 13.015, 6852.18635000001, 0, 60373, 21031.0, 58623.0, 59174.98, 0.49660415868737584, 8.327364885259609, 0.9256379258691038], "isController": false}, {"data": ["SAML", 20000, 2793, 13.965, 2388.6583999999802, 0, 23250, 2278.0, 20999.0, 21031.0, 0.4963650566445598, 4.9652904615853775, 7.516968510911034], "isController": false}, {"data": ["SAML-1", 15299, 14, 0.09150924897052094, 219.6014118569844, 7, 21043, 318.0, 596.0, 925.0, 0.3807211982820836, 0.21622346802489414, 0.32818270060696153], "isController": false}, {"data": ["Login-0", 15793, 0, 0.0, 868.3801051098561, 350, 49329, 1244.6000000000004, 1509.2999999999993, 3386.119999999999, 0.39299471553620113, 0.48525458672585636, 0.5120022323813114], "isController": false}, {"data": ["Logout-2", 17119, 106, 0.6191950464396285, 386.73450552018136, 0, 21051, 496.0, 688.0, 1238.5999999999985, 0.42579876380811493, 0.42921727827970135, 0.5350843269700101], "isController": false}, {"data": ["Login-1", 15793, 0, 0.0, 283.87228518964076, 122, 10504, 285.0, 290.0, 327.0, 0.3930010917581776, 7.151160301048404, 0.295311036246369], "isController": false}, {"data": ["Logout-1", 19016, 1897, 9.975809844341606, 1585.8881994110316, 197, 60480, 231.0, 605.1499999999978, 60156.0, 0.47322643548981264, 0.3638262818815967, 0.3004281675350241], "isController": false}, {"data": ["Logout-0", 19016, 0, 0.0, 294.9681320992839, 130, 10202, 501.0, 710.0, 1244.4899999999943, 0.47322224306795735, 0.48954604711109595, 0.3633020675769376], "isController": false}, {"data": ["Login-2", 327, 0, 0.0, 2187.021406727827, 208, 37621, 250.59999999999985, 21723.0, 34101.39999999997, 0.04499056230085313, 0.04695572847837928, 0.059666561975325084], "isController": false}, {"data": ["Login-3", 327, 1, 0.3058103975535168, 447.23241590214064, 247, 2276, 636.8, 869.7999999999997, 1581.3999999999935, 0.045052740639500925, 0.5696815506616002, 0.030528140052024207], "isController": false}, {"data": ["Initial-3", 8683, 6, 0.06910054128757342, 425.65334561787427, 234, 21023, 672.0, 855.0, 1291.9199999999983, 0.21606982695974622, 2.7369321858110682, 0.146956629938902], "isController": false}, {"data": ["Logout-6", 15098, 0, 0.0, 215.4293946218042, 208, 3588, 216.0, 220.0, 240.0, 0.37574293409539117, 0.3625332215686001, 0.6064827287662374], "isController": false}, {"data": ["Logout-5", 16822, 64, 0.3804541671620497, 276.1383307573405, 42, 21050, 493.0, 604.8499999999985, 1011.0, 0.41864327872098334, 1.1523786841532446, 0.27539456112555216], "isController": false}, {"data": ["Initial-1", 18641, 2, 0.010729038141730594, 252.46585483611312, 117, 2270, 355.0, 648.0, 983.0, 0.4638500073156967, 2.9647718906593856, 0.30064020044386874], "isController": false}, {"data": ["Logout-4", 17012, 190, 1.1168586879849518, 1094.1971549494465, 0, 60294, 767.0, 1749.699999999997, 34529.14999999812, 0.4231396288892339, 0.21234886914895731, 0.3098141192157849], "isController": false}, {"data": ["Initial-2", 10188, 1505, 14.772281115037298, 3257.5280722418543, 197, 60522, 1452.300000000001, 15542.299999999937, 60162.0, 0.25352154313496855, 0.2694009284364897, 0.3243717962048611], "isController": false}, {"data": ["Logout-3", 17013, 1, 0.005877858108505261, 219.56650796449796, 118, 21020, 218.0, 222.0, 297.0, 0.42338350086467236, 0.7687559848989485, 0.4527355231237495], "isController": false}, {"data": ["Logout", 20000, 3257, 16.285, 5000.283299999994, 0, 121169, 5838.200000000012, 21031.0, 60356.990000000005, 0.4961237479480012, 8.589552584759145, 3.2328160334475964], "isController": false}, {"data": ["Logout-7", 15098, 15, 0.0993509074049543, 452.1574380712665, 1, 21046, 719.0, 897.0499999999993, 1340.0300000000007, 0.37574182131901057, 4.769214747850621, 0.39956219244817676], "isController": false}, {"data": ["Initial", 20000, 2872, 14.36, 3964.914999999998, 253, 80279, 9198.800000000134, 21030.0, 60655.0, 0.4967806379150236, 6.376473553639007, 0.9544453069030675], "isController": false}, {"data": ["Initial-0", 18641, 0, 0.0, 491.0372297623539, 342, 10322, 665.0, 870.0, 1533.0, 0.4637980504707621, 0.3211804677609599, 0.18417643424371957], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Percentile 1
            case 8:
            // Percentile 2
            case 9:
            // Percentile 3
            case 10:
            // Throughput
            case 11:
            // Kbytes/s
            case 12:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["503/Service Temporarily Unavailable", 6870, 44.8170135038163, 1.9602248409278968], "isController": false}, {"data": ["Non HTTP response code: java.net.SocketException/Non HTTP response message: Connection reset", 100, 0.6523582751647204, 0.02853311267726196], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to account.qa.saveonfoods.com:443 [account.qa.saveonfoods.com\/54.201.29.127] failed: Connection timed out: connect", 4810, 31.378433035423054, 1.3724427197763005], "isController": false}, {"data": ["500/Internal Server Error", 111, 0.7241176854328397, 0.03167175507176078], "isController": false}, {"data": ["404/Not Found", 1715, 11.187944419074956, 0.48934288241504265], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: account.qa.saveonfoods.com:443 failed to respond", 30, 0.19570748254941614, 0.008559933803178588], "isController": false}, {"data": ["Non HTTP response code: java.net.SocketException/Non HTTP response message: Connection reset by peer: socket write error", 22, 0.1435188205362385, 0.006277284788997632], "isController": false}, {"data": ["Non HTTP response code: java.net.SocketTimeoutException/Non HTTP response message: Read timed out", 1671, 10.90090677800248, 0.47678831283704737], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 350470, 15329, "503/Service Temporarily Unavailable", 6870, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to account.qa.saveonfoods.com:443 [account.qa.saveonfoods.com\/54.201.29.127] failed: Connection timed out: connect", 4810, "404/Not Found", 1715, "Non HTTP response code: java.net.SocketTimeoutException/Non HTTP response message: Read timed out", 1671, "500/Internal Server Error", 111], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": ["SAML-2", 15285, 3, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Connection reset", 2, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to account.qa.saveonfoods.com:443 [account.qa.saveonfoods.com\/54.201.29.127] failed: Connection timed out: connect", 1, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": ["Login", 20000, 2603, "503/Service Temporarily Unavailable", 1306, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to account.qa.saveonfoods.com:443 [account.qa.saveonfoods.com\/54.201.29.127] failed: Connection timed out: connect", 1043, "500/Internal Server Error", 111, "Non HTTP response code: java.net.SocketTimeoutException/Non HTTP response message: Read timed out", 89, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: account.qa.saveonfoods.com:443 failed to respond", 30], "isController": false}, {"data": ["SAML", 20000, 2793, "404/Not Found", 1715, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to account.qa.saveonfoods.com:443 [account.qa.saveonfoods.com\/54.201.29.127] failed: Connection timed out: connect", 1052, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Connection reset", 23, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Connection reset by peer: socket write error", 3, null, null], "isController": false}, {"data": ["SAML-1", 15299, 14, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to account.qa.saveonfoods.com:443 [account.qa.saveonfoods.com\/54.201.29.127] failed: Connection timed out: connect", 8, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Connection reset", 6, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": ["Logout-2", 17119, 106, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to account.qa.saveonfoods.com:443 [account.qa.saveonfoods.com\/54.201.29.127] failed: Connection timed out: connect", 102, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Connection reset", 2, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Connection reset by peer: socket write error", 2, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": ["Logout-1", 19016, 1897, "503/Service Temporarily Unavailable", 1587, "Non HTTP response code: java.net.SocketTimeoutException/Non HTTP response message: Read timed out", 310, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["Login-3", 327, 1, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Connection reset", 1, null, null, null, null, null, null, null, null], "isController": false}, {"data": ["Initial-3", 8683, 6, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to account.qa.saveonfoods.com:443 [account.qa.saveonfoods.com\/54.201.29.127] failed: Connection timed out: connect", 6, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": ["Logout-5", 16822, 64, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to account.qa.saveonfoods.com:443 [account.qa.saveonfoods.com\/54.201.29.127] failed: Connection timed out: connect", 53, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Connection reset", 11, null, null, null, null, null, null], "isController": false}, {"data": ["Initial-1", 18641, 2, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Connection reset", 2, null, null, null, null, null, null, null, null], "isController": false}, {"data": ["Logout-4", 17012, 190, "Non HTTP response code: java.net.SocketTimeoutException/Non HTTP response message: Read timed out", 117, "503/Service Temporarily Unavailable", 54, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to account.qa.saveonfoods.com:443 [account.qa.saveonfoods.com\/54.201.29.127] failed: Connection timed out: connect", 14, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Connection reset", 3, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Connection reset by peer: socket write error", 2], "isController": false}, {"data": ["Initial-2", 10188, 1505, "503/Service Temporarily Unavailable", 1141, "Non HTTP response code: java.net.SocketTimeoutException/Non HTTP response message: Read timed out", 364, null, null, null, null, null, null], "isController": false}, {"data": ["Logout-3", 17013, 1, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to account.qa.saveonfoods.com:443 [account.qa.saveonfoods.com\/54.201.29.127] failed: Connection timed out: connect", 1, null, null, null, null, null, null, null, null], "isController": false}, {"data": ["Logout", 20000, 3257, "503/Service Temporarily Unavailable", 1641, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to account.qa.saveonfoods.com:443 [account.qa.saveonfoods.com\/54.201.29.127] failed: Connection timed out: connect", 1156, "Non HTTP response code: java.net.SocketTimeoutException/Non HTTP response message: Read timed out", 427, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Connection reset", 23, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Connection reset by peer: socket write error", 10], "isController": false}, {"data": ["Logout-7", 15098, 15, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to account.qa.saveonfoods.com:443 [account.qa.saveonfoods.com\/54.201.29.127] failed: Connection timed out: connect", 10, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Connection reset", 4, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Connection reset by peer: socket write error", 1, null, null, null, null], "isController": false}, {"data": ["Initial", 20000, 2872, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to account.qa.saveonfoods.com:443 [account.qa.saveonfoods.com\/54.201.29.127] failed: Connection timed out: connect", 1364, "503/Service Temporarily Unavailable", 1141, "Non HTTP response code: java.net.SocketTimeoutException/Non HTTP response message: Read timed out", 364, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Connection reset", 3, null, null], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
